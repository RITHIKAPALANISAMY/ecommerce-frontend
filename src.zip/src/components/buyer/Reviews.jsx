import { useState, useMemo } from "react";
import { useAuth } from "../../context/AuthContext";
import { useOrders } from "../../context/OrderContext";

/* ================= SAVE REVIEW (LOCAL STORAGE) ================= */
const saveReview = ({ orderId, productId, rating, comment, userEmail }) => {
  const existing = JSON.parse(localStorage.getItem("reviews")) || [];

  const newReview = {
    id: Date.now(),
    orderId,          // ✅ IMPORTANT
    productId,
    rating,
    comment,
    userEmail,
    createdAt: new Date().toISOString(),
  };

  localStorage.setItem(
    "reviews",
    JSON.stringify([newReview, ...existing])
  );
};

export default function Reviews({ productId }) {
  const { user } = useAuth();
  const { orders } = useOrders();

  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  /* ================= FIND ELIGIBLE ORDER ================= */
  const eligibleOrder = useMemo(() => {
  if (!user) return null;

  const reviews =
    JSON.parse(localStorage.getItem("reviews")) || [];

  return orders.find(order => {
    if (order.status !== "Delivered") return false;

    // ✅ FINAL FIX
    if (order.buyerId !== user.id) return false;

    const hasProduct = order.items.some(
      item => item.productId === productId
    );

    const alreadyReviewed = reviews.some(
      r =>
        r.orderId === order.id &&
        r.productId === productId &&
        r.userEmail === user.email
    );

    return hasProduct && !alreadyReviewed;
  });
}, [orders, user, productId]);


  /* ================= LOGIN CHECK ================= */
  if (!user) {
    return (
      <p className="mt-6 text-sm text-gray-500">
        Login to write a review.
      </p>
    );
  }

  /* ================= DELIVERY + REVIEW CHECK ================= */
  if (!eligibleOrder) {
    return (
      <p className="mt-6 text-sm text-gray-500">
        You can review this product only after it is delivered
        and only once per order.
      </p>
    );
  }

  /* ================= SUBMIT ================= */
  const handleSubmit = () => {
    if (!rating || !comment.trim()) {
      alert("Please give rating and comment");
      return;
    }

    saveReview({
      orderId: eligibleOrder.id, // ✅ FIX
      productId,
      rating,
      comment,
      userEmail: user.email,
    });

    setSubmitted(true);
    setRating(0);
    setComment("");
  };

  return (
    <div className="mt-8 rounded-xl bg-white p-6 shadow">
      <h3 className="mb-4 text-lg font-semibold">
        Write a Review
      </h3>

      {submitted && (
        <p className="mb-3 text-sm text-green-600">
          ✅ Review submitted successfully
        </p>
      )}

      {/* ⭐ RATING */}
      <div className="mb-4 flex items-center gap-2">
        {[1, 2, 3, 4, 5].map(n => (
          <button
            key={n}
            onClick={() => setRating(n)}
            className={`text-2xl ${
              n <= rating
                ? "text-yellow-400"
                : "text-gray-300"
            }`}
          >
            ★
          </button>
        ))}
      </div>

      {/* COMMENT */}
      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        rows={4}
        placeholder="Write your review here..."
        className="w-full rounded-lg border px-4 py-2 text-sm focus:ring-2 focus:ring-red-500"
      />

      {/* ACTION */}
      <button
        onClick={handleSubmit}
        className="mt-4 rounded-lg bg-red-600 px-6 py-2 text-sm text-white hover:bg-red-700"
      >
        Submit Review
      </button>
    </div>
  );
}
