import { useAuth } from "../../context/AuthContext";
import { useSellerProducts } from "../../context/SellerProductContext";
import SellerProductCard from "../../components/seller/SellerProductCard";

export default function SellerProducts() {
  const { user } = useAuth();
  const { sellerProducts } = useSellerProducts();

  const myProducts = sellerProducts.filter(
    (p) => p.sellerId === user.email
  );

  return (
    <div className="seller-products">
      <div className="products-header">
        <h3>My Products</h3>
        <p>{myProducts.length} products</p>
      </div>

      {myProducts.length === 0 ? (
        <p className="empty">No products added yet.</p>
      ) : (
        <div className="seller-product-grid">
          {myProducts.map((product) => (
            <SellerProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
