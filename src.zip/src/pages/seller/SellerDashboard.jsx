import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useProducts } from "../../context/ProductContext";
import { useOrders } from "../../context/OrderContext";

import SellerProducts from "./SellerProducts";
import SellerOrders from "./SellerOrders";
import SellerAddProduct from "./SellerAddProduct";

import "../../styles/seller/seller.css";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

export default function SellerDashboard() {
  const { user } = useAuth();
  const { products } = useProducts();
  const { orders } = useOrders();

  const [tab, setTab] = useState("overview");
  const [showAddProduct, setShowAddProduct] = useState(false);

  const sellerId = user?.email;
  const seller = user?.sellerInfo;

  /* ================= SELLER PRODUCTS ================= */
  const sellerProducts = products.filter(
    (p) => p.sellerId === sellerId
  );

  /* ================= SELLER ORDERS ================= */
  const sellerOrders = orders.filter((order) =>
    order.items.some((item) => item.sellerId === sellerId)
  );

  /* ================= TOTAL REVENUE ================= */
  const revenue = sellerOrders.reduce((total, order) => {
    const sellerItems = order.items.filter(
      (item) => item.sellerId === sellerId
    );

    return (
      total +
      sellerItems.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      )
    );
  }, 0);

  /* ================= DAILY REVENUE ================= */
  const chartData = Object.values(
    sellerOrders.reduce((acc, order) => {
      const date = order.date;

      const orderRevenue = order.items
        .filter((i) => i.sellerId === sellerId)
        .reduce((s, i) => s + i.price * i.quantity, 0);

      if (!acc[date]) {
        acc[date] = { date, revenue: 0 };
      }

      acc[date].revenue += orderRevenue;
      return acc;
    }, {})
  );

  return (
    <div className="seller-dashboard">

      {/* ================= HEADER ================= */}
      <div className="seller-header">
        <h2>Seller Dashboard</h2>
        <p>{user?.email}</p>
      </div>

      {/* ================= SELLER INFO ================= */}
      {seller && (
        <div className="seller-info-card">
          <h3>{seller.storeName}</h3>
          <p><strong>Owner:</strong> {seller.ownerName || "—"}</p>
          <p><strong>Phone:</strong> {seller.phone}</p>
          {seller.gst && <p><strong>GST:</strong> {seller.gst}</p>}
          <p className="seller-address">{seller.address}</p>
        </div>
      )}

      {/* ================= TABS ================= */}
      <div className="seller-tabs">
        <button
          className={tab === "overview" ? "active" : ""}
          onClick={() => setTab("overview")}
        >
          OVERVIEW
        </button>
        <button
          className={tab === "products" ? "active" : ""}
          onClick={() => setTab("products")}
        >
          PRODUCTS
        </button>
        <button
          className={tab === "orders" ? "active" : ""}
          onClick={() => setTab("orders")}
        >
          ORDERS
        </button>
      </div>

      {/* ================= CONTENT ================= */}
      <div className="seller-content">

        {/* ================= OVERVIEW ================= */}
        {tab === "overview" && (
          <div className="overview-layout">

            {/* ================= ANALYTICS CARDS ================= */}
            <div className="analytics-grid">

              <div className="analytics-card products">
                <div className="card-left">
                  <span className="card-icon">📦</span>
                </div>
                <div className="card-content">
                  <p className="card-title">Products</p>
                  <h3 className="card-value">{sellerProducts.length}</h3>
                </div>
              </div>

              <div className="analytics-card orders">
                <div className="card-left">
                  <span className="card-icon">🧾</span>
                </div>
                <div className="card-content">
                  <p className="card-title">Orders</p>
                  <h3 className="card-value">{sellerOrders.length}</h3>
                </div>
              </div>

              <div className="analytics-card revenue">
                <div className="card-left">
                  <span className="card-icon">💰</span>
                </div>
                <div className="card-content">
                  <p className="card-title">Revenue</p>
                  <h3 className="card-value">₹{revenue}</h3>
                </div>
              </div>

              {/* ================= DAILY REVENUE ================= */}
              <div className="analytics-card chart">
                <p className="card-title">Daily Revenue</p>

                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={120}>
                    <BarChart data={chartData}>
                      <XAxis dataKey="date" hide />
                      <YAxis hide />
                      <Tooltip formatter={(v) => `₹${v}`} />
                      <Bar
                        dataKey="revenue"
                        fill="#e11d48"
                        radius={[6, 6, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="chart-placeholder" />
                )}
              </div>

            </div>
          </div>
        )}

        {/* ================= PRODUCTS ================= */}
        {tab === "products" && (
          <>
            <div className="products-top-bar">
              <h3>My Products</h3>
              <button
                className="add-product-btn"
                onClick={() => setShowAddProduct(true)}
              >
                + Add Product
              </button>
            </div>

            <SellerProducts />

            {showAddProduct && (
              <div className="modal-overlay">
                <div className="modal">
                  <SellerAddProduct
                    onClose={() => setShowAddProduct(false)}
                  />
                  <button
                    className="close-btn"
                    onClick={() => setShowAddProduct(false)}
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {/* ================= ORDERS ================= */}
        {tab === "orders" && <SellerOrders />}

      </div>
    </div>
  );
}
