import { useState } from "react";
import { useOrders } from "../../context/OrderContext";
import { useAuth } from "../../context/AuthContext";
import "../../styles/seller/sellerOrders.css";

export default function SellerOrders() {
  const { orders } = useOrders();
  const { user } = useAuth();

  const [statusFilter, setStatusFilter] = useState("ALL");

  /* ================= SELLER ORDERS ONLY ================= */
  const sellerOrders = orders
    .map((order) => {
      const sellerItems = order.items.filter(
        (item) => item.sellerId === user.email
      );

      if (sellerItems.length === 0) return null;

      return {
        ...order,
        items: sellerItems,
      };
    })
    .filter(Boolean);

  /* ================= STATUS FILTER ================= */
  const filteredOrders =
    statusFilter === "ALL"
      ? sellerOrders
      : sellerOrders.filter(
          (order) => order.status === statusFilter
        );

  /* ================= REVENUE ================= */
  const totalRevenue = filteredOrders.reduce(
    (sum, order) =>
      sum +
      order.items.reduce(
        (s, i) => s + i.price * i.quantity,
        0
      ),
    0
  );

  return (
    <div className="seller-orders">
      <h2>My Orders</h2>

      {/* FILTER */}
      <div className="orders-filter">
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="ALL">All Orders</option>
          <option value="Placed">Placed</option>
          <option value="Shipped">Shipped</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      {/* STATS */}
      <div className="seller-stats">
        <div>
          <strong>{filteredOrders.length}</strong>
          <span>Total Orders</span>
        </div>
        <div>
          <strong>₹{totalRevenue}</strong>
          <span>Total Revenue</span>
        </div>
      </div>

      {filteredOrders.length === 0 && (
        <p>No orders found.</p>
      )}

      {filteredOrders.map((order) => (
        <div key={order.id} className="order-card">
          <div className="order-header">
            <span>Order ID: {order.id}</span>
            <span>{order.date}</span>
            <span>Buyer: {order.buyerEmail}</span>
            <span className="order-status">
              Status: <strong>{order.status}</strong>
            </span>
          </div>

          {order.items.map((item) => (
            <div key={item.productId} className="order-item">
              <strong>{item.title}</strong>
              <span>Qty: {item.quantity}</span>
              <span>₹{item.price}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
