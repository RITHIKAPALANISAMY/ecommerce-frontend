import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  BarChart3,
  Heart,
  Truck,
  RotateCcw,
  ShieldCheck,
  Package,
} from "lucide-react";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { useCompare } from "../../context/CompareContext";
import Reviews from "../../components/buyer/Reviews";
import api from "../../api/axios";

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { compareItems, addToCompare, removeFromCompare } = useCompare();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [activeImg, setActiveImg] = useState(0);

  /* ================= FETCH PRODUCT FROM BACKEND ================= */

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });

    const fetchProduct = async () => {
      try {
        setLoading(true);
        const res = await api.get(`/api/products/${id}`);
        setProduct(res.data);
      } catch (err) {
        console.error("Failed to load product", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  if (loading) {
    return (
      <div className="p-10 text-center text-gray-500">
        Loading product...
      </div>
    );
  }

  if (!product) {
    return (
      <h2 className="p-10 text-center text-lg font-semibold">
        Product not found
      </h2>
    );
  }

  const isCompared = compareItems.some(
    (item) => item.id === product.id
  );

  const stock = product.stock ?? 0;
  const LOW_STOCK_LIMIT = 5;
  const stockStatus =
    stock === 0 ? "OUT" : stock <= LOW_STOCK_LIMIT ? "LOW" : "IN";

  const toggleWishlist = () =>
    isInWishlist(product.id)
      ? removeFromWishlist(product.id)
      : addToWishlist(product.id);

  const handleAddToCart = () =>
    addToCart({ ...product, quantity: qty });

  const handleBuyNow = () => {
    addToCart({ ...product, quantity: qty, buyNow: true });
    navigate("/cart");
  };

  return (
    <div className="bg-gray-50 px-4 py-8">
      <div className="mx-auto max-w-7xl rounded-2xl bg-white p-6 shadow-md">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2">

          {/* IMAGE */}
          <div>
            <div className="flex h-[420px] items-center justify-center rounded-xl bg-gray-100">
              <img
                src={product.images?.[activeImg]}
                alt={product.title}
                className="max-h-full max-w-full object-contain"
              />
            </div>

            <div className="mt-4 flex gap-3">
              {product.images?.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className={`h-16 w-16 rounded-lg border p-1 ${
                    i === activeImg
                      ? "border-red-500 ring-2 ring-red-200"
                      : "border-gray-200"
                  }`}
                >
                  <img
                    src={img}
                    alt=""
                    className="h-full w-full object-contain"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* DETAILS */}
          <div>
            {product.brand && (
              <p className="text-sm uppercase tracking-wide text-gray-500">
                {product.brand}
              </p>
            )}

            <div className="mt-1 flex flex-col gap-4 sm:flex-row sm:justify-between">
              <h1 className="text-2xl font-semibold text-gray-900">
                {product.title}
              </h1>

              <div className="flex items-center gap-3">
                {/* WISHLIST */}
                <button
                  onClick={toggleWishlist}
                  className={`rounded-full border p-2 ${
                    isInWishlist(product.id)
                      ? "border-red-500 bg-red-50 text-red-600"
                      : "border-gray-300 text-gray-500"
                  }`}
                >
                  <Heart
                    size={18}
                    fill={
                      isInWishlist(product.id)
                        ? "currentColor"
                        : "none"
                    }
                  />
                </button>

                {/* COMPARE */}
                <button
                  onClick={() =>
                    isCompared
                      ? removeFromCompare(product.id)
                      : addToCompare(product)
                  }
                  className="flex items-center gap-2 rounded-full border px-4 py-2 text-sm"
                >
                  <BarChart3 size={16} />
                  {isCompared
                    ? "Added to Compare"
                    : "Add to Compare"}
                </button>
              </div>
            </div>

            {/* PRICE */}
            <div className="mt-4 flex items-end gap-3">
              <span className="text-3xl font-bold text-red-600">
                ₹{product.price}
              </span>
              {product.mrp && (
                <span className="text-sm text-gray-400 line-through">
                  ₹{product.mrp}
                </span>
              )}
            </div>

            {/* QUANTITY */}
            <div className="mt-6">
              <p className="mb-2 text-sm font-medium">Quantity</p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => qty > 1 && setQty(qty - 1)}
                  className="h-8 w-8 rounded border"
                >
                  −
                </button>
                <span>{qty}</span>
                <button
                  onClick={() =>
                    qty < stock && setQty(qty + 1)
                  }
                  disabled={stock === 0}
                  className="h-8 w-8 rounded border"
                >
                  +
                </button>

                <span
                  className={`text-sm font-medium ${
                    stockStatus === "OUT"
                      ? "text-red-600"
                      : stockStatus === "LOW"
                      ? "text-orange-500"
                      : "text-green-600"
                  }`}
                >
                  {stockStatus === "OUT" && "Out of stock"}
                  {stockStatus === "LOW" && `Only ${stock} left`}
                </span>
              </div>
            </div>

            {/* ACTIONS */}
            <div className="mt-8 flex gap-3">
              <button
                onClick={handleAddToCart}
                className="flex-1 rounded-xl bg-red-600 py-3 font-semibold text-white"
              >
                Add to Cart
              </button>
              <button
                onClick={handleBuyNow}
                disabled={stock === 0}
                className="flex-1 rounded-xl border py-3 font-semibold"
              >
                Buy Now
              </button>
            </div>

            {/* TRUST BADGES */}
            <ul className="mt-6 grid grid-cols-2 gap-3 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <Truck size={16} /> Free Delivery
              </li>
              <li className="flex items-center gap-2">
                <RotateCcw size={16} /> 7 Days Return
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck size={16} /> Genuine Product
              </li>
              <li className="flex items-center gap-2">
                <Package size={16} /> Secure Packaging
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="mx-auto mt-10 max-w-7xl">
        <Reviews productId={product.id} />
      </div>
    </div>
  );
}
