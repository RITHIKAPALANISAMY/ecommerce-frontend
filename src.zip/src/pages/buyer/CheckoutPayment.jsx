import { useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import CheckoutSteps from "./CheckoutSteps";
import { useOrders } from "../../context/OrderContext";
import { useAuth } from "../../context/AuthContext";
import { useSellerProducts } from "../../context/SellerProductContext";
import { useState } from "react";

export default function CheckoutPayment() {
  const navigate = useNavigate();
  const { placeOrder } = useOrders();
  const { user } = useAuth();
  const { clearCart } = useCart();
  const { reduceStockAfterOrder } = useSellerProducts();

  const [method, setMethod] = useState("cod");
  const [error, setError] = useState("");

  /* 🔑 SNAPSHOT CHECKOUT DATA */
  const [checkoutAmount] = useState(() =>
    JSON.parse(localStorage.getItem("checkoutAmount"))
  );

  const [checkoutAddress] = useState(() =>
    JSON.parse(localStorage.getItem("checkoutAddress"))
  );

  const checkoutItems =
    JSON.parse(localStorage.getItem("cart")) || [];

  const handlePlaceOrder = () => {
    setError("");

    if (!user) {
      navigate("/login");
      return;
    }

    if (!checkoutItems.length) {
      setError("No available items to place order.");
      return;
    }

    const orderItems = checkoutItems.map((item) => ({
      productId: item.id,
      title: item.title,
      price: item.price,
      quantity: item.qty,
      image: item.image,
      sellerId: item.sellerId || "admin",
    }));

    const order = {
      id: Date.now(),
      buyerEmail: user.email,
      items: orderItems,
      address: checkoutAddress,
      amount: checkoutAmount,
      paymentMethod: method,
      status: "Placed",
      placedDate: new Date().toISOString().split("T")[0],
      trackingId: `TRK-${Date.now()}`,
    };

    placeOrder(order);

    const sellerItems = orderItems
      .filter((i) => i.sellerId)
      .map((i) => ({
        productId: i.productId,
        quantity: i.quantity,
      }));

    if (sellerItems.length) {
      reduceStockAfterOrder(sellerItems);
    }

    clearCart();
    localStorage.removeItem("checkoutAddress");
    localStorage.removeItem("checkoutAmount");
    localStorage.setItem("orderPlaced", "true");

    navigate("/OrderSuccess", { replace: true });
  };

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-6">
      <CheckoutSteps currentStep={3} />

      <div className="mx-auto mt-6 grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-2 rounded-xl bg-white p-6 shadow">
          <h2 className="mb-4 text-lg font-semibold">
            Payment Options
          </h2>

          {error && (
            <div className="mb-3 rounded bg-red-100 px-3 py-2 text-sm text-red-700">
              ⚠️ {error}
            </div>
          )}

          {[
            ["upi", "📱 UPI"],
            ["card", "💳 Card"],
            ["netbanking", "🏦 Net Banking"],
            ["wallet", "👛 Wallet"],
            ["cod", "💵 Cash on Delivery"],
          ].map(([key, label]) => (
            <div
              key={key}
              onClick={() => setMethod(key)}
              className={`mb-3 cursor-pointer rounded-lg border p-4 font-medium ${
                method === key
                  ? "border-red-600 bg-red-50"
                  : "hover:bg-gray-50"
              }`}
            >
              {label}
            </div>
          ))}

          <div className="mt-6 flex justify-between">
            <button
              onClick={() => navigate("/checkout/summary")}
              className="rounded border px-4 py-2"
            >
              Back
            </button>

            <button
              onClick={handlePlaceOrder}
              className="rounded bg-red-600 px-6 py-2 text-white hover:bg-red-700"
            >
              Place Order →
            </button>
          </div>
        </div>

        <div className="rounded-xl bg-white p-6 shadow">
          <h3 className="mb-4 font-semibold">Price Details</h3>

          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>₹{checkoutAmount?.subtotal}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Shipping</span>
            <span>₹{checkoutAmount?.shipping}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>GST</span>
            <span>₹{checkoutAmount?.gst}</span>
          </div>

          {checkoutAmount?.discount > 0 && (
            <div className="flex justify-between text-sm text-green-600">
              <span>Discount</span>
              <span>-₹{checkoutAmount.discount}</span>
            </div>
          )}

          <hr className="my-3" />

          <div className="flex justify-between font-bold">
            <span>Total</span>
            <span>₹{checkoutAmount?.total}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
