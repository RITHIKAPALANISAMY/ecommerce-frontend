import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { jsPDF } from "jspdf";

export default function OrderSuccess() {
  const [order, setOrder] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // ✅ ONLY TRUST orderPlaced FLAG
    const placed = localStorage.getItem("orderPlaced");
    if (!placed) {
      navigate("/cart", { replace: true });
      return;
    }

    // ✅ GET LATEST ORDER SAFELY
    const orders =
      JSON.parse(localStorage.getItem("orders")) || [];

    if (orders.length === 0) {
      navigate("/", { replace: true });
      return;
    }

    const latestOrder = orders[orders.length - 1];
    setOrder(latestOrder);

    // ✅ CLEAR FLAG AFTER LOAD
    localStorage.removeItem("orderPlaced");
  }, [navigate]);

  if (!order) return null;

  /* ================= PDF INVOICE ================= */
  const downloadInvoice = () => {
    const doc = new jsPDF();
    let y = 20;

    doc.setFontSize(18);
    doc.text("SHOPVERSE INVOICE", 14, y);

    y += 10;
    doc.setFontSize(11);
    doc.text(`Order ID: ${order.id}`, 14, y);
    y += 6;
    doc.text(`Order Date: ${order.placedDate}`, 14, y);

    y += 10;
    doc.setFontSize(13);
    doc.text("Delivery Address", 14, y);

    y += 6;
    doc.setFontSize(11);
    doc.text(order.address?.name || "", 14, y);
    y += 5;
    doc.text(order.address?.phone || "", 14, y);
    y += 5;
    doc.text(
      `${order.address?.address}, ${order.address?.city}, ${order.address?.state} - ${order.address?.pincode}`,
      14,
      y
    );

    y += 10;
    doc.setFontSize(13);
    doc.text("Order Items", 14, y);

    y += 6;
    doc.setFontSize(11);
    order.items.forEach((item) => {
      doc.text(
        `${item.title} | Qty: ${item.quantity} | ₹${item.price * item.quantity}`,
        14,
        y
      );
      y += 6;
    });

    y += 6;
    doc.line(14, y, 195, y);

    y += 8;
    doc.setFontSize(12);
    doc.text(`Total Paid: ₹${order.amount?.total}`, 14, y);

    y += 6;
    doc.text(
      `Payment Method: ${order.paymentMethod || "Cash on Delivery"}`,
      14,
      y
    );

    doc.save(`Invoice_${order.id}.pdf`);
  };

  return (
    <div className="os-page">
      <div className="os-success-icon">✔</div>

      <h2>Order Placed Successfully!</h2>
      <p>Thank you for shopping with ShopVerse</p>

      <button onClick={downloadInvoice}>
        ⬇ Download Invoice (PDF)
      </button>

      <div className="os-card">
        <div className="os-row">
          <span>Order ID</span>
          <strong>{order.id}</strong>
        </div>

        <div className="os-row">
          <span>Order Date</span>
          <strong>{order.placedDate}</strong>
        </div>

        <hr />

        <h4>Delivery Address</h4>
        <p>{order.address?.name}</p>
        <p>{order.address?.phone}</p>
        <p>
          {order.address?.address}, {order.address?.city},{" "}
          {order.address?.state} - {order.address?.pincode}
        </p>

        <hr />

        <h4>Order Items</h4>
        {order.items.map((item, index) => (
          <div key={index} className="os-item">
            <strong>{item.title}</strong>
            <p>Qty: {item.quantity}</p>
            <p>₹{item.price}</p>
          </div>
        ))}

        <hr />

        <div className="os-total">
          <span>Total Paid</span>
          <strong>₹{order.amount?.total}</strong>
        </div>

        <p className="os-payment">
          Payment Method:{" "}
          <strong>{order.paymentMethod}</strong>
        </p>
      </div>

      <div className="os-actions">
        <button onClick={() => navigate("/orders")}>
          View Orders
        </button>
        <button onClick={() => navigate("/")}>
          Continue Shopping
        </button>
      </div>
    </div>
  );
}
