import "../../styles/orders.css";
import { useAuth } from "../../context/AuthContext";
import { useProducts } from "../../context/ProductContext";
import { useOrders } from "../../context/OrderContext";
import { useState } from "react";

export default function Orders() {
  const { user } = useAuth();
  const { addReview, products } = useProducts(); // kept (not removed)
  const { getBuyerOrders, canReviewProduct } = useOrders(); // kept

  const orders = getBuyerOrders(user.email);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [openOrderId, setOpenOrderId] = useState(null);

  const deliveredCount = orders.filter(
    (o) => o.status === "Delivered"
  ).length;
  const cancelledCount = orders.filter(
    (o) => o.status === "Cancelled"
  ).length;

  const filteredOrders = orders.filter((order) => {
    const matchSearch = order.items.some((i) =>
      i.title.toLowerCase().includes(search.toLowerCase())
    );
    const matchStatus =
      statusFilter === "ALL" || order.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="orders-page">
      <h2>My Orders</h2>

      {/* SUMMARY */}
      <div className="orders-summary">
        <div>
          <strong>{orders.length}</strong>
          <span>Total Orders</span>
        </div>
        <div>
          <strong>{deliveredCount}</strong>
          <span>Delivered</span>
        </div>
        <div>
          <strong>{cancelledCount}</strong>
          <span>Cancelled</span>
        </div>
      </div>

      {/* FILTER */}
      <div className="orders-toolbar">
        <input
          type="text"
          placeholder="Search your orders"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="ALL">All</option>
          <option value="Delivered">Delivered</option>
          <option value="Shipped">Shipped</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      {/* ORDERS LIST */}
      {filteredOrders.map((order) => {
        const total = order.items.reduce(
          (sum, i) => sum + i.price,
          0
        );

        return (
          <div key={order.id} className="order-wrapper">
            {/* ORDER CARD */}
            <div className="order-card">
              {/* IMAGE */}
              <div className="order-image-box">
                <img
                  src={order.items[0]?.image || "/placeholder.png"}
                  alt={order.items[0]?.title}
                  onError={(e) =>
                    (e.target.src = "/placeholder.png")
                  }
                />
              </div>

              {/* INFO */}
              <div className="order-info-box">
                <h4 className="product-name">
                  {order.items[0]?.title}
                  {order.items.length > 1 && (
                    <span className="more-items">
                      {" "}
                      +{order.items.length - 1} more item(s)
                    </span>
                  )}
                </h4>

                <p className="order-id">
                  Order ID: {order.id}
                </p>
                <p className="order-date">
                  Placed on {order.placedDate}
                </p>

                <span
                  className={`status-badge ${order.status.toLowerCase()}`}
                >
                  {order.status}
                </span>
              </div>

              {/* ACTIONS */}
              <div className="order-action-box">
                <p className="order-price">₹{total}</p>

                <button
                  className="view-btn"
                  onClick={() =>
                    setOpenOrderId(
                      openOrderId === order.id
                        ? null
                        : order.id
                    )
                  }
                >
                  {openOrderId === order.id
                    ? "Hide Details"
                    : "View Order"}
                </button>
              </div>
            </div>

            {/* EXPANDED DETAILS */}
            {openOrderId === order.id && (
              <div className="order-details">
                {order.items.map((item) => (
                  <div
                    key={item.productId}
                    className="order-detail-item"
                  >
                    <img
  src={order.items[0]?.image || "/placeholder.png"}
  alt="product"
  className="order-preview"
  onError={(e) => {
    e.target.onerror = null; // 🔥 STOP infinite loop
    e.target.src = "/placeholder.png";
  }}
/>

                    <div>
                      <p className="detail-title">
                        {item.title}
                      </p>
                      <p className="detail-price">
                        ₹{item.price}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
