import { createContext, useContext, useEffect, useState } from "react";

const SellerProductContext = createContext();

export function SellerProductProvider({ children }) {
  const [sellerProducts, setSellerProducts] = useState(() => {
    const saved = localStorage.getItem("sellerProducts");
    return saved ? JSON.parse(saved) : [];
  });

  /* SAVE TO LOCAL STORAGE */
  useEffect(() => {
    localStorage.setItem(
      "sellerProducts",
      JSON.stringify(sellerProducts)
    );
  }, [sellerProducts]);

  /* ADD PRODUCT */
  const addSellerProduct = (product) => {
    setSellerProducts((prev) => [...prev, product]);
  };

  /* DELETE PRODUCT */
  const deleteSellerProduct = (id) => {
    setSellerProducts((prev) =>
      prev.filter((p) => p.id !== id)
    );
  };

  /* EDIT PRODUCT */
  const updateSellerProduct = (updatedProduct) => {
    setSellerProducts((prev) =>
      prev.map((p) =>
        p.id === updatedProduct.id ? updatedProduct : p
      )
    );
  };

  return (
    <SellerProductContext.Provider
      value={{
        sellerProducts,
        addSellerProduct,
        deleteSellerProduct,
        updateSellerProduct
      }}
    >
      {children}
    </SellerProductContext.Provider>
  );
}

export const useSellerProducts = () =>
  useContext(SellerProductContext);
