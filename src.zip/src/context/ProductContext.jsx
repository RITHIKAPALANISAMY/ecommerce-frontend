import { createContext, useContext, useEffect, useState } from "react";
import axios from "axios";

const ProductContext = createContext();

const PRODUCT_API = "http://localhost:8082/api/products";

export function ProductProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);

  /* ================= FETCH ALL PRODUCTS ================= */

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await axios.get(PRODUCT_API);
      setProducts(response.data);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  /* ================= GET PRODUCT BY ID ================= */

  const getProductById = async (id) => {
    try {
      const response = await axios.get(`${PRODUCT_API}/${id}`);
      return response.data;
    } catch (error) {
      console.error("Failed to fetch product:", error);
      return null;
    }
  };

  /* ================= GET PRODUCTS BY CATEGORY ================= */

  const getProductsByCategory = async (categoryId) => {
    try {
      const response = await axios.get(
        `${PRODUCT_API}/category/${categoryId}`
      );
      return response.data;
    } catch (error) {
      console.error("Failed to fetch category products:", error);
      return [];
    }
  };

  /* ================= CREATE PRODUCT ================= */

  const createProduct = async (productData) => {
    try {
      const response = await axios.post(PRODUCT_API, productData);
      await fetchProducts();
      return response.data;
    } catch (error) {
      console.error("Product creation failed:", error);
      return null;
    }
  };

  /* ================= DELETE PRODUCT ================= */

  const deleteProduct = async (id) => {
    try {
      await axios.delete(`${PRODUCT_API}/${id}`);
      await fetchProducts();
    } catch (error) {
      console.error("Delete failed:", error);
    }
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        loading,
        fetchProducts,
        getProductById,
        getProductsByCategory,
        createProduct,
        deleteProduct,
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}

export const useProducts = () => useContext(ProductContext);
