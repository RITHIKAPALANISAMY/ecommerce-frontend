import { createContext, useContext, useEffect, useState } from "react";
import baseProducts from "../data/products";

const ProductContext = createContext();

export function ProductProvider({ children }) {
  /* ================= LOAD SELLER PRODUCTS ================= */
  const [sellerProducts, setSellerProducts] = useState(() => {
    const saved = localStorage.getItem("products");
    return saved ? JSON.parse(saved) : [];
  });

  /* ================= WATCH STORAGE CHANGES ================= */
  useEffect(() => {
    const syncProducts = () => {
      const saved = localStorage.getItem("products");
      setSellerProducts(saved ? JSON.parse(saved) : []);
    };

    window.addEventListener("storage", syncProducts);
    return () =>
      window.removeEventListener("storage", syncProducts);
  }, []);

  /* ================= MERGE BASE + SELLER PRODUCTS ================= */
  const products = [...baseProducts, ...sellerProducts].map(
    (p) => ({
      ...p,
      title: p.title || p.name || "Unnamed Product",
      images:
        p.images ||
        (p.image ? [p.image] : []) ||
        [],
      reviews: p.reviews || [],
    })
  );

  return (
    <ProductContext.Provider value={{ products }}>
      {children}
    </ProductContext.Provider>
  );
}

export const useProducts = () =>
  useContext(ProductContext);
