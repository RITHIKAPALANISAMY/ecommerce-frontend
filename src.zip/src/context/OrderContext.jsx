import { createContext, useContext, useEffect, useState } from "react";
import { useCart } from "./CartContext";
import { useAuth } from "./AuthContext";

const OrderContext = createContext();

export const OrderProvider = ({ children }) => {
  const { cartItems, clearCart } = useCart();
  const { user } = useAuth(); // ✅ GET LOGGED-IN USER

  /* ================= STATE ================= */
  const [orders, setOrders] = useState(() => {
    const stored = localStorage.getItem("orders");
    return stored ? JSON.parse(stored) : [];
  });

  /* ================= PERSIST ================= */
  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders));
  }, [orders]);

  /* ================= PLACE ORDER (BUYER) ================= */
  const placeOrder = ({ buyerName, address, amount }) => {
    if (!cartItems.length || !user?.email) return;

    const newOrder = {
      id: Date.now(),

      buyerEmail: user.email.toLowerCase(), // ✅ ALWAYS PRESENT
      buyerName: buyerName || user.username || "Customer",

      items: cartItems.map((item) => ({
        productId: item.id,
        title: item.title,
        price: item.price,
        image: item.image,
        quantity: item.quantity,
        sellerId: item.sellerId,
        status: "placed",
      })),

      address: address || {},
      amount: {
        total: Number(amount?.total ?? amount ?? 0),
      },

      status: "placed",
      placedDate: new Date().toISOString().split("T")[0],
      paymentMethod: "cod",
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart(); // ✅ clear cart after order
  };

  /* ================= UPDATE STATUS (ADMIN) ================= */
  const updateOrderStatus = (orderId, status, extra = {}) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, status: status.toLowerCase(), ...extra }
          : o
      )
    );
  };

  /* ================= BUYER ORDERS ================= */
  const getBuyerOrders = (buyerEmail) => {
    return orders.filter(
      (o) =>
        o.buyerEmail?.toLowerCase() ===
        buyerEmail?.toLowerCase()
    );
  };

  /* ================= SELLER ORDERS ================= */
  const getSellerOrders = (sellerId) => {
    return orders
      .map((order) => {
        const sellerItems = order.items.filter(
          (item) => item.sellerId === sellerId
        );

        return sellerItems.length
          ? { ...order, items: sellerItems }
          : null;
      })
      .filter(Boolean);
  };

  /* ================= SELLER REVENUE ================= */
  const getSellerRevenue = (sellerId) => {
    return getSellerOrders(sellerId).reduce(
      (sum, order) =>
        sum +
        order.items.reduce(
          (s, i) => s + i.price * i.quantity,
          0
        ),
      0
    );
  };

  /* ================= SELLER UPDATE ITEM STATUS ================= */
  const updateSellerOrderStatus = (
    orderId,
    sellerId,
    status,
    extra = {}
  ) => {
    setOrders((prev) =>
      prev.map((order) => {
        if (order.id !== orderId) return order;

        return {
          ...order,
          status: status.toLowerCase(),
          ...extra,
          items: order.items.map((item) =>
            item.sellerId === sellerId
              ? { ...item, status: status.toLowerCase() }
              : item
          ),
        };
      })
    );
  };

  /* ================= SELLER CANCEL ================= */
  const cancelOrderBySeller = (orderId, sellerId) => {
    updateSellerOrderStatus(orderId, sellerId, "cancelled", {
      cancelledDate: new Date().toISOString().split("T")[0],
    });
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        placeOrder,
        updateOrderStatus,
        getBuyerOrders,
        getSellerOrders,
        getSellerRevenue,
        updateSellerOrderStatus,
        cancelOrderBySeller,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => useContext(OrderContext);
