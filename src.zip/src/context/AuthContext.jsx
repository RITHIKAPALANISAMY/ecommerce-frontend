import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("user");
    return saved ? JSON.parse(saved) : null;
  });

  /* =========================
     LOGIN
  ========================= */
  const login = (email, password) => {
    // Admin login
    if (email === "admin@shopverse.com" && password === "admin123") {
      const adminUser = {
        username: "Admin",
        email,
        role: "admin",
        phone: "",
        address: "",
        sellerInfo: null,
        profileImage: "",
      };
      setUser(adminUser);
      localStorage.setItem("user", JSON.stringify(adminUser));
      return adminUser;
    }

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const found = users.find(
      (u) => u.email === email && u.password === password
    );
    if (!found) return null;

    const loggedUser = {
      username: found.name,
      email: found.email,
      role: found.role || "buyer",
      phone: found.phone || "",
      address: found.address || "",
      sellerInfo: found.sellerInfo || null,
      profileImage: found.profileImage || "",
    };

    setUser(loggedUser);
    localStorage.setItem("user", JSON.stringify(loggedUser));
    return loggedUser;
  };

  /* =========================
     SIGNUP
  ========================= */
  const signup = (form) => {
    const users = JSON.parse(localStorage.getItem("users")) || [];

    const exists = users.find((u) => u.email === form.email);
    if (exists) return false;

    const newUser = {
      name: form.name,
      email: form.email,
      password: form.password,
      role: "buyer",
      phone: "",
      address: "",
      sellerInfo: null,
      profileImage: "",
    };

    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    return true;
  };

  /* =========================
     UPDATE USER (GENERIC)
  ========================= */
  const updateUser = (data) => {
    if (!user) return;

    // Update users list
    let users = JSON.parse(localStorage.getItem("users")) || [];

    users = users.map((u) =>
      u.email === user.email
        ? {
            ...u,
            name: data.username ?? u.name,
            phone: data.phone ?? u.phone,
            address: data.address ?? u.address,
            profileImage: data.profileImage ?? u.profileImage,
          }
        : u
    );

    localStorage.setItem("users", JSON.stringify(users));

    // Update logged-in user
    const updatedUser = {
      ...user,
      ...data,
    };

    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
  };

  /* =========================
     UPGRADE TO SELLER
  ========================= */
  const updateUserRole = (sellerData) => {
    if (!user) return;

    let users = JSON.parse(localStorage.getItem("users")) || [];

    users = users.map((u) =>
      u.email === user.email
        ? {
            ...u,
            role: "seller",
            phone: sellerData.phone,
            address: sellerData.address,
            sellerInfo: sellerData,
          }
        : u
    );

    localStorage.setItem("users", JSON.stringify(users));

    const updatedUser = {
      ...user,
      role: "seller",
      phone: sellerData.phone,
      address: sellerData.address,
      sellerInfo: sellerData,
    };

    setUser(updatedUser);
    localStorage.setItem("user", JSON.stringify(updatedUser));
  };

  /* =========================
     HELPERS
  ========================= */
  const verifyEmail = (email) => {
    const users = JSON.parse(localStorage.getItem("users")) || [];
    return users.some((u) => u.email === email);
  };

  const resetPassword = (email, newPassword) => {
    let users = JSON.parse(localStorage.getItem("users")) || [];

    users = users.map((u) =>
      u.email === email ? { ...u, password: newPassword } : u
    );

    localStorage.setItem("users", JSON.stringify(users));
  };

  const deleteAccount = () => {
    if (!user) return;

    const email = user.email;

    let users = JSON.parse(localStorage.getItem("users")) || [];
    users = users.filter((u) => u.email !== email);
    localStorage.setItem("users", JSON.stringify(users));

    localStorage.removeItem("user");
    localStorage.removeItem("cart");
    localStorage.removeItem("wishlist");

    let orders = JSON.parse(localStorage.getItem("orders")) || [];
    orders = orders.filter((o) => o.buyerEmail !== email);
    localStorage.setItem("orders", JSON.stringify(orders));

    setUser(null);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        updateUserRole,
        updateUser,
        verifyEmail,
        resetPassword,
        deleteAccount,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
