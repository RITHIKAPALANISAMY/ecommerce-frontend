import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ allowedRoles }) {
  const { user, loading } = useAuth();

  // Wait until auth loads
  if (loading) return null;

  // Not logged in
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If roles restriction exists
  if (allowedRoles && allowedRoles.length > 0) {
    const userRoles = user.roles || [];

    const hasAccess = userRoles.some((role) =>
      allowedRoles.includes(role.toUpperCase())
    );

    if (!hasAccess) {
      return <Navigate to="/unauthorized" replace />;
    }
  }

  return <Outlet />;
}
