import sunscreen1 from "../assets/product/sunscreen1.jpg";
import sunscreen2 from "../assets/product/sunscreen2.webp";
import sunscreen3 from "../assets/product/sunscreen3.webp";

import sneakers1 from "../assets/product/sneakers1.avif";
import sneakers2 from "../assets/product/sneakers2.avif";
import sneakers3 from "../assets/product/sneakers3.avif";

const products = [
  {
    id: 1,
    title: "Sunscreen SPF 50 PA+++ 100ml",
    brand: "SunGuard",
    price: 899,
    mrp: 1499,
    discount: 40,
    rating: 4.8,
    reviews: 3456,
    stock: 150,
    images: [sunscreen1, sunscreen2, sunscreen3],
    description:
      "Broad spectrum sunscreen with SPF 50 and non-greasy formula.",
      reviews: [
  {
    id: 1,
    rating: 4,
    title: "Good",
    user: "Kamandla Mallesh",
    date: "4 months ago",
    location: "Hyderabad",
    likes: 8,
    dislikes: 0,
  },
  {
    id: 2,
    rating: 5,
    title: "Nice product ✌️",
    user: "Flipkart Customer",
    date: "Apr, 2024",
    location: "Navi Mumbai",
    likes: 3,
    dislikes: 0,
  },
  {
    id: 3,
    rating: 5,
    title: "Nice",
    user: "Sandhya rani Malik",
    date: "Feb, 2024",
    location: "Baleshwar",
    likes: 3,
    dislikes: 0,
  },
]

  },

  {
    id: 2,
    title: "Running Sneakers for Men",
    brand: "Nike",
    price: 2999,
    mrp: 4999,
    discount: 40,
    rating: 4.6,
    reviews: 2120,
    stock: 80,
    images: [sneakers1, sneakers2, sneakers3],
    description:
      "Lightweight running shoes with breathable mesh design.",
    reviews: [
  {
    id: 1,
    rating: 4,
    title: "Good",
    user: "Kamandla Mallesh",
    date: "4 months ago",
    location: "Hyderabad",
    likes: 8,
    dislikes: 0,
  },
  {
    id: 2,
    rating: 5,
    title: "Nice product ✌️",
    user: "Flipkart Customer",
    date: "Apr, 2024",
    location: "Navi Mumbai",
    likes: 3,
    dislikes: 0,
  },
  {
    id: 3,
    rating: 5,
    title: "Nice",
    user: "Sandhya rani Malik",
    date: "Feb, 2024",
    location: "Baleshwar",
    likes: 3,
    dislikes: 0,
  },
]

  },
];

export default products;
