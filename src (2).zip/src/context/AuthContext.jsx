import { createContext, useContext, useState, useEffect } from "react";
import api from "../api/axios";


const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  /* ================= LOAD USER ON APP START ================= */
  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (!token) {
      setLoading(false);
      return;
    }

    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const res = await api.get("/user/profile");
      setUser(res.data);
    } catch (err) {
      console.warn("User load failed. Logging out.");
      logout();
    } finally {
      setLoading(false);
    }
  };

  /* ================= REGISTER ================= */
const signup = async ({ name, email, password }) => {
  try {
    // 1️⃣ Register
    await api.post("/auth/register", {
      name,
      email,
      password,
    });

    // 2️⃣ Login immediately
    const res = await api.post("/auth/login", {
      email,
      password,
    });

    const { accessToken, refreshToken } = res.data;

    localStorage.setItem("accessToken", accessToken);
    localStorage.setItem("refreshToken", refreshToken);

    // 3️⃣ Load user profile
    await fetchUser();

    return true;
  } catch (err) {
    console.error(err.response?.data);
    return false;
  }
};



  /* ================= LOGIN ================= */
  const login = async (email, password) => {
    try {
      const res = await api.post("/auth/login", {
        email,
        password,
      });

      const { accessToken, refreshToken } = res.data;

      localStorage.setItem("accessToken", accessToken);
      localStorage.setItem("refreshToken", refreshToken);

      await fetchUser();

      return true;
    } catch (err) {
      console.error("Login error:", err.response?.data);
      return false;
    }
  };

  /* ================= LOGOUT ================= */
  const logout = async () => {
    try {
      const refreshToken = localStorage.getItem("refreshToken");

      if (refreshToken) {
        await api.post("/auth/logout", { refreshToken });
      }
    } catch (err) {
      console.warn("Logout API failed");
    }

    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    setUser(null);
  };

  /* ================= CONTEXT VALUE ================= */
  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        signup,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
