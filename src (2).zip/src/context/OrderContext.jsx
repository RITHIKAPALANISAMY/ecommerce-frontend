import { createContext, useContext, useState } from "react";
import axios from "axios";
import { useCart } from "./CartContext";
import { useAuth } from "./AuthContext";

const OrderContext = createContext();

const ORDER_API = "http://localhost:8083/api/orders";
const PRODUCT_API = "http://localhost:8082/api/products";

export const OrderProvider = ({ children }) => {
  const { cartItems, clearCart } = useCart();
  const { user } = useAuth();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);

  /* ================= FETCH BUYER ORDERS ================= */
  const fetchBuyerOrders = async () => {
    if (!user?.email) return;

    try {
      setLoading(true);
      const response = await axios.get(
        `${ORDER_API}/buyer/${user.email.toLowerCase()}`
      );
      setOrders(response.data || []);
    } catch (error) {
      console.error("Failed to fetch buyer orders:", error);
    } finally {
      setLoading(false);
    }
  };

  /* ================= PLACE ORDER ================= */
  const placeOrder = async ({ address, amount, paymentMethod }) => {
    if (!cartItems.length || !user?.email) return;

    try {
      setLoading(true);

      const newOrder = {
        buyerEmail: user.email.toLowerCase(),
        buyerName: user.name || "Customer",
        items: cartItems.map((item) => ({
          productId: item.id,
          title: item.title,
          price: item.price,
          image: item.image,
          quantity: item.quantity || 1,
          sellerEmail: item.sellerEmail,
        })),
        address,
        amount,
        status: "placed",
        paymentMethod,
      };

      /* -------- SAVE ORDER -------- */
      await axios.post(ORDER_API, newOrder);

      /* -------- REDUCE STOCK -------- */
      for (const item of cartItems) {
        await axios.post(
          `${PRODUCT_API}/reduce-stock`,
          null,
          {
            params: {
              productId: item.id,
              quantity: item.quantity || 1,
            },
          }
        );
      }

      clearCart();
      await fetchBuyerOrders();

    } catch (error) {
      console.error("Order placement failed:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        loading,
        fetchBuyerOrders,
        placeOrder,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => useContext(OrderContext);
