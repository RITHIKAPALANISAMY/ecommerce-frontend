import { createContext, useContext, useState } from "react";

const CartContext = createContext();

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]);
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  const addToCart = (product) => {
    setCartItems(prev => {
      const exists = prev.find(i => i.id === product.id);
      if (exists) {
        return prev.map(i =>
          i.id === product.id ? { ...i, qty: i.qty + 1 } : i
        );
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const addQty = id => {
    setCartItems(items =>
      items.map(i =>
        i.id === id ? { ...i, qty: i.qty + 1 } : i
      )
    );
  };

  const reduceQty = id => {
    setCartItems(items =>
      items.map(i =>
        i.id === id && i.qty > 1 ? { ...i, qty: i.qty - 1 } : i
      )
    );
  };

  const removeItem = id => {
    setCartItems(items => items.filter(i => i.id !== id));
  };

  const applyCoupon = (code, subtotal) => {
    if (code === "WELCOME10") {
      if (subtotal < 500) return "Minimum ₹500 required";
      setAppliedCoupon({ code, type: "PERCENT", value: 10 });
      return null;
    }

    if (code === "SAVE500") {
      if (subtotal < 2000) return "Minimum ₹2000 required";
      setAppliedCoupon({ code, type: "FLAT", value: 500 });
      return null;
    }

    return "Invalid coupon code";
  };

  const removeCoupon = () => setAppliedCoupon(null);

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      addQty,
      reduceQty,
      removeItem,
      applyCoupon,
      removeCoupon,
      appliedCoupon
    }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
