import { useMemo, useEffect, useState } from "react";
import { Line, Bar, Doughnut } from "react-chartjs-2";
import { useOrders } from "../../context/OrderContext";
import { exportToCSV } from "../../utils/exportReports";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

const COLORS = {
  primary: "#931012",
  success: "#16A34A",
  warning: "#F59E0B",
  danger: "#DC2626",
  info: "#2563EB",
};

const baseOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "bottom",
      labels: { boxWidth: 12, padding: 12 },
    },
  },
};

const doughnutOptions = {
  ...baseOptions,
  cutout: "65%",
};

const normalizeStatus = (status) =>
  String(status || "").toUpperCase();

export default function Analytics() {
  const { orders = [] } = useOrders();
  const [, forceUpdate] = useState(0);

  /* REALTIME SYNC */
  useEffect(() => {
    const sync = () => forceUpdate((v) => v + 1);
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);

  const getAmountValue = (amount) => {
    if (typeof amount === "number") return amount;
    if (typeof amount === "object" && amount !== null)
      return amount.total || 0;
    return 0;
  };

  const salesByDate = useMemo(() => {
    const map = {};
    orders.forEach((o) => {
      if (!o.placedDate) return;
      map[o.placedDate] =
        (map[o.placedDate] || 0) +
        getAmountValue(o.amount);
    });
    return {
      labels: Object.keys(map),
      values: Object.values(map),
    };
  }, [orders]);

  const salesData = {
    labels: salesByDate.labels,
    datasets: [
      {
        label: "Sales (₹)",
        data: salesByDate.values,
        borderColor: COLORS.primary,
        backgroundColor: "rgba(147,16,18,0.15)",
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const totalRevenue = orders.reduce(
    (sum, o) => sum + getAmountValue(o.amount),
    0
  );

  const ordersVsRevenue = {
    labels: ["Performance"],
    datasets: [
      {
        label: "Orders",
        data: [orders.length],
        backgroundColor: COLORS.warning,
      },
      {
        label: "Revenue (₹)",
        data: [totalRevenue],
        backgroundColor: COLORS.info,
      },
    ],
  };

  /* ✅ FIXED STATUS COUNT */
  const statusCounts = useMemo(() => {
    const counts = {
      PLACED: 0,
      SHIPPED: 0,
      DELIVERED: 0,
      CANCELLED: 0,
    };

    orders.forEach((o) => {
      const s = normalizeStatus(o.status);
      if (counts[s] !== undefined) {
        counts[s] += 1;
      }
    });

    return counts;
  }, [orders]);

  const orderStatusData = {
    labels: ["Placed", "Shipped", "Delivered", "Cancelled"],
    datasets: [
      {
        data: [
          statusCounts.PLACED,
          statusCounts.SHIPPED,
          statusCounts.DELIVERED,
          statusCounts.CANCELLED,
        ],
        backgroundColor: [
          COLORS.warning,
          COLORS.info,
          COLORS.success,
          COLORS.danger,
        ],
      },
    ],
  };

  const productSales = useMemo(() => {
    const map = {};
    orders.forEach((o) =>
      o.items?.forEach((i) => {
        map[i.title] =
          (map[i.title] || 0) +
          i.price * (i.quantity || 1);
      })
    );
    return map;
  }, [orders]);

  const topProductsData = {
    labels: Object.keys(productSales),
    datasets: [
      {
        label: "Revenue (₹)",
        data: Object.values(productSales),
        backgroundColor: COLORS.primary,
      },
    ],
  };

  const exportAnalytics = () => {
    exportToCSV("analytics_summary", [
      {
        TotalOrders: orders.length,
        TotalRevenue: totalRevenue,
        Placed: statusCounts.PLACED,
        Shipped: statusCounts.SHIPPED,
        Delivered: statusCounts.DELIVERED,
        Cancelled: statusCounts.CANCELLED,
      },
    ]);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">
          Analytics Dashboard
        </h2>

        <button
          onClick={exportAnalytics}
          className="bg-[#931012] text-white px-4 py-2 rounded-lg text-sm hover:opacity-90"
        >
          Export Analytics
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold mb-4">📈 Sales Trend</h3>
          <div className="h-[260px]">
            <Line data={salesData} options={baseOptions} />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold mb-4">
            📦 Orders vs Revenue
          </h3>
          <div className="h-[260px]">
            <Bar data={ordersVsRevenue} options={baseOptions} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold mb-4">
            🏆 Top Selling Products
          </h3>
          <div className="h-[260px]">
            <Bar
              data={topProductsData}
              options={{ ...baseOptions, indexAxis: "y" }}
            />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold mb-4">
            🟢 Order Status
          </h3>
          <div className="h-[260px] flex justify-center">
            <Doughnut
              data={orderStatusData}
              options={doughnutOptions}
            />
          </div>
        </div>
      </div>
    </div>
  );
}