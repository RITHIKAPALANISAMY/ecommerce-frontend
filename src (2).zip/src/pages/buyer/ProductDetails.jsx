import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import products from "../../data/products";
import { useCart } from "../../context/CartContext";
import "../../styles/productDetails.css";

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, setCartItems } = useCart();

  const product = products.find(p => p.id === Number(id));
  const [qty, setQty] = useState(1);
  const [activeImg, setActiveImg] = useState(0);

  if (!product) {
    return <h2 style={{ padding: 40 }}>Product not found</h2>;
  }

  const handleAddToCart = () => {
    addToCart({ ...product, qty });
  };

  const handleBuyNow = () => {
    setCartItems([{ ...product, qty }]);
    navigate("/checkout");
  };

  return (
    <div className="pd-page">
      <div className="pd-container">

        {/* IMAGE GALLERY */}
        <div className="pd-images">
          <img
            className="pd-main-img"
            src={product.images[activeImg]}
            alt={product.title}
          />

          <div className="pd-thumbs">
            {product.images.map((img, i) => (
              <img
                key={i}
                src={img}
                alt=""
                className={i === activeImg ? "active" : ""}
                onClick={() => setActiveImg(i)}
              />
            ))}
          </div>
        </div>

        {/* PRODUCT INFO */}
        <div className="pd-info">
          <p className="brand">{product.brand}</p>
          <h1>{product.title}</h1>

          <div className="rating">
            <span className="badge-green">
              {product.rating} ★
            </span>
            <span className="reviews">
              {product.reviews} ratings & reviews
            </span>
          </div>

          <div className="price">
            <span className="current">₹{product.price}</span>
            <span className="old">₹{product.mrp}</span>
            <span className="off">{product.discount}% off</span>
          </div>

          <p className="tax">Inclusive of all taxes</p>

          {/* QTY */}
          <div className="qty">
            <span>Quantity</span>
            <div className="qty-box">
              <button onClick={() => qty > 1 && setQty(qty - 1)}>-</button>
              <span>{qty}</span>
              <button onClick={() => setQty(qty + 1)}>+</button>
              <span className="stock">
                ({product.stock} available)
              </span>
            </div>
          </div>

          {/* ACTIONS */}
          <div className="pd-actions">
            <button className="btn-cart" onClick={handleAddToCart}>
              🛒 Add to Cart
            </button>
            <button className="btn-buy" onClick={handleBuyNow}>
              Buy Now
            </button>
          </div>

          {/* HIGHLIGHTS */}
          <ul className="highlights">
            <li>🚚 Free Delivery</li>
            <li>↩️ 7 Days Return & Exchange</li>
            <li>🛡️ 1 Year Warranty</li>
          </ul>
        </div>
      </div>

      {/* DESCRIPTION */}
      <div className="pd-desc">
        <h3>Product Description</h3>
        <p>{product.description}</p>
      </div>

      {/* REVIEWS (SIMPLE) */}
      <div className="pd-reviews">
        <h3>Ratings & Reviews</h3>
        <p>⭐ 4.8 out of 5</p>
        <p>👍 Very good product, worth the price.</p>
        <p>👍 Lightweight and easy to use.</p>
      </div>
    </div>
  );
}
