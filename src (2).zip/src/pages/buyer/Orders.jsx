export default function Orders() {
  // Mock order data (later replace with API)
  const orders = [
    {
      id: "ORD123456",
      date: "12 Jan 2026",
      total: 4599,
      status: "Delivered",
    },
    {
      id: "ORD123457",
      date: "20 Jan 2026",
      total: 1999,
      status: "Shipped",
    },
  ];

  return (
    <div className="orders-page">
      <h2>My Orders</h2>

      {orders.map((order) => (
        <div key={order.id} className="order-card">
          <div>
            <p><strong>Order ID:</strong> {order.id}</p>
            <p><strong>Date:</strong> {order.date}</p>
          </div>

          <div>
            <p><strong>Total:</strong> ₹{order.total}</p>
            <p className={`status ${order.status.toLowerCase()}`}>
              {order.status}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
