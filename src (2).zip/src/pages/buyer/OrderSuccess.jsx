export default function OrderSuccess() {
  return (
    <div className="order-success">
      <div className="success-card">
        <h2>✅ Order Placed Successfully</h2>
        <p>Thank you for shopping with ShopVerse</p>

        <p><strong>Order ID:</strong> ORD123456789</p>
        <p><strong>Payment:</strong> Cash on Delivery</p>

        <button className="btn">View Orders</button>
      </div>
    </div>
  );
}
