import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { jsPDF } from "jspdf";

export default function OrderSuccess() {
  const navigate = useNavigate();
  const location = useLocation();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    if (location.state?.order) {
      setOrder(location.state.order);
    } else {
      navigate("/", { replace: true });
    }
  }, [location, navigate]);

  if (!order) return null;

  const downloadInvoice = () => {
    const doc = new jsPDF();
    let y = 20;

    doc.setFontSize(18);
    doc.text("SHOPVERSE INVOICE", 14, y);
    y += 10;

    doc.setFontSize(12);
    doc.text(`Order ID: ${order.id}`, 14, y);
    y += 6;
    doc.text(`Order Date: ${order.placedDate}`, 14, y);

    y += 10;
    doc.text(`Total Paid: ₹${order.amount?.total}`, 14, y);
    y += 6;
    doc.text(`Payment Method: ${order.paymentMethod}`, 14, y);

    doc.save(`Invoice_${order.id}.pdf`);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
      <div className="max-w-xl w-full bg-white p-8 rounded-2xl shadow-md text-center">
        <div className="text-green-600 text-4xl mb-4">✔</div>
        <h2 className="text-2xl font-semibold mb-2">
          Order Placed Successfully!
        </h2>
        <p className="text-gray-500 mb-6">
          Thank you for shopping with ShopVerse
        </p>

        <button
          onClick={downloadInvoice}
          className="mb-4 bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700"
        >
          Download Invoice
        </button>

        <div className="flex justify-center gap-4 mt-4">
          <button
            onClick={() => navigate("/orders")}
            className="border px-4 py-2 rounded-lg hover:bg-gray-100"
          >
            View Orders
          </button>

          <button
            onClick={() => navigate("/")}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
}