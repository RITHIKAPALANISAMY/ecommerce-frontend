import { useNavigate } from "react-router-dom";
import { useCart } from "../../context/CartContext";

export default function Checkout() {
  const { cartItems, clearCart } = useCart();
  const navigate = useNavigate();

  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.qty,
    0
  );

  return (
    <div className="checkout-page">
      <h2>Checkout</h2>

      {cartItems.map((item) => (
        <div key={item.id}>
          {item.title} × {item.qty} = ₹{item.price * item.qty}
        </div>
      ))}

      <h3>Total: ₹{total}</h3>

      <button
        className="btn full"
        onClick={() => {
          clearCart();
          navigate("/order-success");
        }}
      >
        Place Order
      </button>
    </div>
  );
}
