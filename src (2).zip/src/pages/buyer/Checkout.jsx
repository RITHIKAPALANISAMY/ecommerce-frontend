import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";

export default function Checkout() {
  const { user } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Only run guard for /checkout routes
    if (!location.pathname.startsWith("/checkout")) return;

    if (!user) {
      navigate("/login", { replace: true });
      return;
    }

    const isBuyer = user.roles?.includes("buyer");

    if (!isBuyer) {
      navigate("/", { replace: true });
      return;
    }

    if (!cartItems || cartItems.length === 0) {
      navigate("/cart", { replace: true });
    }

  }, [user, cartItems, location.pathname, navigate]);

  return <Outlet />;
}