import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";
import { useOrders } from "../../context/OrderContext";
import CheckoutSteps from "./CheckoutSteps";
import paymentApi from "../../api/paymentApi";
import { CreditCard, Wallet, Banknote } from "lucide-react";

export default function CheckoutPayment() {

  const navigate = useNavigate();
  const { user } = useAuth();
  const { clearCart } = useCart();
  const { placeOrder } = useOrders();

  const [method, setMethod] = useState("card");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const checkoutAmount = JSON.parse(localStorage.getItem("checkoutAmount"));
  const checkoutAddress = JSON.parse(localStorage.getItem("checkoutAddress"));
  const checkoutItems =
    JSON.parse(localStorage.getItem("checkoutItems")) || [];

  const cleanUp = () => {
    clearCart();
    localStorage.removeItem("checkoutItems");
    localStorage.removeItem("checkoutAmount");
    localStorage.removeItem("checkoutAddress");
  };

  const handlePlaceOrder = async () => {

    if (!checkoutAmount || !checkoutAddress || checkoutItems.length === 0) {
      setError("Checkout data missing");
      return;
    }

    const orderData = {
      id: Date.now(),
      placedDate: new Date().toLocaleDateString(),
      address: checkoutAddress,
      items: checkoutItems,
      amount: checkoutAmount,
      paymentMethod:
        method === "cod" ? "Cash on Delivery" : "Online Payment",
    };

    if (method === "cod") {
      await placeOrder({
        address: checkoutAddress,
        amount: checkoutAmount.total,
        paymentMethod: "cod",
      });

      navigate("/order-success", {
        replace: true,
        state: { order: orderData },
      });

      cleanUp();
      return;
    }

    try {

      setLoading(true);

      const { data } = await paymentApi.post("/payment/create-order", {
        amount: checkoutAmount.total,
      });

      const options = {
        key: "rzp_test_SH4Bhcf8mzwGFx",
        amount: checkoutAmount.total * 100,
        currency: "INR",
        name: "ShopVerse",
        description: "Order Payment",
        order_id: data.orderId,

        handler: async function (response) {

          try {

            await paymentApi.post("/payment/verify", {
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
              userEmail: user.email,
              amount: checkoutAmount.total,
              paymentMethod: method,
            });

            await placeOrder({
              address: checkoutAddress,
              amount: checkoutAmount.total,
              paymentMethod: method,
            });

            navigate("/order-success", {
              replace: true,
              state: { order: orderData },
            });

            cleanUp();

          } catch (err) {
            console.error(err.response?.data || err);
            setError("Payment verification failed");
          }
        },

        modal: {
          ondismiss: function () {
            setError("Payment cancelled");
          },
        },

        prefill: {
          name: user?.name,
          email: user?.email,
        },

        theme: {
          color: "#dc2626",
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();

      setLoading(false);

    } catch (err) {
      setLoading(false);
      setError("Payment failed. Try again.");
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-gray-50 px-4 py-4">
      <CheckoutSteps currentStep={3} />

      <div className="mx-auto mt-4 grid max-w-5xl grid-cols-1 gap-4 md:grid-cols-3">
        <div className="md:col-span-2 rounded-xl bg-white p-5 shadow-sm">

          <h2 className="mb-4 text-lg font-semibold text-gray-800">
            Payment Options
          </h2>

          {error && (
            <div className="mb-3 rounded bg-red-100 px-3 py-2 text-sm text-red-700">
              {error}
            </div>
          )}

          <div
            onClick={() => setMethod("card")}
            className={`mb-2 flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-3 ${
              method === "card" ? "border-red-600 bg-red-50" : ""
            }`}
          >
            <CreditCard size={18} /> Card / UPI / Net Banking
          </div>

          <div
            onClick={() => setMethod("wallet")}
            className={`mb-2 flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-3 ${
              method === "wallet" ? "border-red-600 bg-red-50" : ""
            }`}
          >
            <Wallet size={18} /> Wallet
          </div>

          <div
            onClick={() => setMethod("cod")}
            className={`mb-2 flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-3 ${
              method === "cod" ? "border-red-600 bg-red-50" : ""
            }`}
          >
            <Banknote size={18} /> Cash on Delivery
          </div>

          <div className="mt-4 flex justify-between">
            <button
              onClick={() => navigate("/checkout/summary")}
              className="rounded-lg border px-4 py-2 text-sm"
            >
              Back
            </button>

            <button
              onClick={handlePlaceOrder}
              disabled={loading}
              className="rounded-lg bg-red-600 px-6 py-2 text-white"
            >
              {loading ? "Processing..." : "Pay Now →"}
            </button>
          </div>
        </div>

        <div className="rounded-xl bg-white p-5 shadow-sm">
          <h3 className="mb-4 font-semibold text-gray-800">
            Price Details
          </h3>
          <div className="flex justify-between font-semibold">
            <span>Total</span>
            <span>₹{checkoutAmount?.total}</span>
          </div>
        </div>
      </div>
    </div>
  );
}