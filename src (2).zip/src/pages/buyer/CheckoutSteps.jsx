export default function CheckoutSteps({ step }) {
  return (
    <div className="checkout-steps">
      <div className={step >= 1 ? "active" : ""}>Address</div>
      <div className={step >= 2 ? "active" : ""}>Summary</div>
      <div className={step >= 3 ? "active" : ""}>Payment</div>
    </div>
  );
}
