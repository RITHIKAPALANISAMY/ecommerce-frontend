import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const cartCount = cartItems.reduce((sum, item) => sum + item.qty, 0);

  return (
    <nav className="navbar">
      <Link to="/" className="logo">ShopVerse</Link>

      <input
        className="search"
        placeholder="Search for Products, Brands and More"
      />

      <div className="nav-actions">
        {user ? (
          <div className="user-menu">
            <span onClick={() => setOpen(!open)}>👤 {user.email}</span>
            {open && (
              <div className="dropdown">
                <Link to="/orders">Orders</Link>
                <button onClick={logout}>Logout</button>
              </div>
            )}
          </div>
        ) : (
          <Link to="/login">Login</Link>
        )}

        <div className="cart" onClick={() => navigate("/cart")}>
          🛒 {cartCount > 0 && <span className="badge">{cartCount}</span>}
        </div>
      </div>
    </nav>
  );
}
