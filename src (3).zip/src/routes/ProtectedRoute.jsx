import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ allowedRoles }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && allowedRoles.length > 0) {
    const roles = [];

    if (Array.isArray(user.roles)) {
      roles.push(...user.roles);
    }

    if (user.role) {
      roles.push(user.role);
    }

    const normalizedUserRoles = roles.map(r =>
      r.toString().toUpperCase()
    );

    const hasAccess = normalizedUserRoles.some(role =>
      allowedRoles.map(r => r.toUpperCase()).includes(role)
    );

    if (!hasAccess) {
      return <Navigate to="/unauthorized" replace />;
    }
  }

  return <Outlet />;
}