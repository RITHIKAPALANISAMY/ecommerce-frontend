import axios from "axios";

const api = axios.create({
  headers: {
    "Content-Type": "application/json",
  },
});

/* Automatically choose service based on URL */
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  // 🔥 Auto routing
  if (config.url.startsWith("/api/products") ||
      config.url.startsWith("/api/categories") ||
      config.url.startsWith("/api/inventory")) {

    config.baseURL = "http://localhost:8082"; // Product service
  } else {
    config.baseURL = "http://localhost:8081"; // Auth service
  }

  return config;
});

export default api;
